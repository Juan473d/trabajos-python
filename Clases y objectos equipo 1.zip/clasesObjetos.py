class CuentaBancaria:
    def __new__(cls,numero_cuenta, titular, saldo):
        if saldo < 0:
            print(f"No se puede crear la cuenta {numero_cuenta} con saldo negativo: ${saldo}")
            return None  # No se crea la instancia
        print("Creando una nueva cuenta bancaria...")
        return super().__new__(cls)

    def __init__(self, numero_cuenta, titular, saldo=0):
        print("Inicializando la cuenta bancaria...")
        self.numero_cuenta = numero_cuenta
        self.titular = titular
        self.saldo = saldo
        
    def __str__(self):
        return f"CuentaBancaria(numero de cuenta = {self.numero_cuenta}, titular = {self.titular}, saldo = {self.saldo})"

    def depositar(self, monto):
        self.saldo += monto
        print(f"Se depositaron ${monto}. Nuevo saldo: ${self.saldo}")

    def retirar(self, monto):
        if monto > self.saldo:
            print("Fondos insuficientes.")
        else:
            self.saldo -= monto
            print(f"Se retiraron ${monto}. Nuevo saldo: ${self.saldo}")

    def mostrar_informacion(self):
        print(f"Cuenta: {self.numero_cuenta}")
        print(f"Titular: {self.titular}")
        print(f"Saldo: ${self.saldo}")


# Pruebas
# cuenta1 = CuentaBancaria("12345", "Keiner", 1000)  # Correcta
cuenta2 = CuentaBancaria("54321", "Ana", -500)     # No se crea

# if cuenta1:
#     cuenta1.mostrar_informacion()
#     cuenta1.depositar(200)
#     cuenta1.retirar(500)

# print(cuenta1)